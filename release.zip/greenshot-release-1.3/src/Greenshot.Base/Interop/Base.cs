﻿using System;

namespace Greenshot.Base.Interop
{
    /// <summary>
    /// Common properties that has appreared in almost all objects
    /// </summary>
    public interface ICommon : IDisposable
    {
    }
}