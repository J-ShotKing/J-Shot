﻿using System;

namespace Greenshot.Base.Core
{
    public delegate void LanguageChangedHandler(object sender, EventArgs e);
}