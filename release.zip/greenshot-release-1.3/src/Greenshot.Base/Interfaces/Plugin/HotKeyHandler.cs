﻿namespace Greenshot.Base.Interfaces.Plugin
{
    public delegate void HotKeyHandler();
}